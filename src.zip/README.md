<h2 align="center">Hi there! 👋 I'm Axocoder, a Discord Bot Developer</h2>

<div align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=Axocoder0&theme=blueberry&show_icons=true&hide_border=false&count_private=false" height="150" alt="GitHub Stats"  />
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Axocoder0&theme=blueberry&show_icons=true&hide_border=false&layout=compact" height="150" alt="Top Languages"  />
</div>

<img align="right" height="150" src="https://raw.githubusercontent.com/devSouvik/devSouvik/master/gif3.gif" alt="Animated Coding" />

<h3>About Me</h3>
<div align="center">
  🤖 I love creating Discord bots!<br>
  🌱 Currently learning Python.<br>
  🎥 I'm also a content creator.
</div>

### Skills
<div align="left">
  <a href="https://www.python.org/">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" height="30" alt="Python"  />
  </a>
  <img width="12" />
  <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" height="30" alt="JavaScript"  />
  </a>
</div>

### Connect with Me
<div align="left">
  <a href="https://youtube.com/@AxoCoder?si=WYggB1myrZNTRoAT">
    <img src="https://img.shields.io/static/v1?message=Youtube&logo=youtube&label=&color=FF0000&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="YouTube" />
  </a>
  <a href="https://www.instagram.com/memezonebgmi/">
    <img src="https://img.shields.io/static/v1?message=Instagram&logo=instagram&label=&color=E4405F&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="Instagram" />
  </a>
  <a href="https://discord.gg/codersplanet">
    <img src="https://img.shields.io/static/v1?message=Discord&logo=discord&label=&color=7289DA&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="Discord" />
  </a>
</div>

<br clear="both">


### Bot Code Credit Goes To Corwin#0001